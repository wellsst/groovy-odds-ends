package esportal.services.xsltManager;

// -----( IS Java Code Template v1.2
// -----( CREATED: 2013-03-05 20:24:25 CST
// -----( ON-HOST: dhttpgw

import com.wm.data.*;
import com.wm.util.Values;
import com.wm.app.b2b.server.Service;
import com.wm.app.b2b.server.ServiceException;
// --- <<IS-START-IMPORTS>> ---
import java.io.*;
// --- <<IS-END-IMPORTS>> ---

public final class util

{
	// ---( internal utility methods )---

	final static util _instance = new util();

	static util _newInstance() { return new util(); }

	static util _cast(Object o) { return (util)o; }

	// ---( server methods )---




	public static final void deleteFile (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(deleteFile)>> ---
		// @subtype unknown
		// @sigtype java 3.5
		// [i] field:0:required fileName
		// [o] field:0:required status
		// [o] field:0:required error
		// Basic wrapper around Java File.mkdirs()
		
		// pipeline
		IDataCursor pipelineCursor = pipeline.getCursor();
		
		String fileName = IDataUtil.getString( pipelineCursor, "fileName" );
		
		try {
		  File f = new File(fileName);
		  boolean b=f.delete();
		  IDataUtil.put( pipelineCursor, "status", b ? "success" : "fail");
		  if (!b) {
			  if (f.exists()) {
				  IDataUtil.put( pipelineCursor, "error", "Could not delete: " + fileName + ", check file permissions and file is closed"); 
			  } else {
				  IDataUtil.put( pipelineCursor, "error", "Could not delete: " + fileName + ", file does not exist");  
			  }
			  
		  }
		}
		catch(Exception e) {
			IDataUtil.put( pipelineCursor, "error", e.getMessage());
		}
		finally {
			pipelineCursor.destroy();
		}
		// --- <<IS-END>> ---

                
	}



	public static final void dirExists (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(dirExists)>> ---
		// @subtype unknown
		// @sigtype java 3.5
		// [i] field:0:required dir
		// [o] field:0:required error
		// [o] field:0:required exists
		// Basic wrapper around Java File.exists()
		
		// pipeline
		IDataCursor pipelineCursor = pipeline.getCursor();
		
		String dir = IDataUtil.getString( pipelineCursor, "dir" );
		
		try {
		  File f = new File(dir);
		  boolean b = f.exists() && f.isDirectory();
		  IDataUtil.put( pipelineCursor, "exists", b ? "true" : "false");
		}
		catch(Exception e) {
			IDataUtil.put( pipelineCursor, "error", e.toString());
		}
		finally {
			pipelineCursor.destroy();
		}
		// --- <<IS-END>> ---

                
	}



	public static final void fileExists (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(fileExists)>> ---
		// @subtype unknown
		// @sigtype java 3.5
		// [i] field:0:required fileName
		// [o] field:0:required exists
		// [o] field:0:required error
		// Basic wrapper around Java File.exists()
		
		// pipeline
		IDataCursor pipelineCursor = pipeline.getCursor();
		
		String fileName = IDataUtil.getString( pipelineCursor, "fileName" );
		
		try {
		  File f = new File(fileName);
		  boolean b = f.exists() && f.isFile();
		  IDataUtil.put( pipelineCursor, "exists", b ? "true" : "false");
		}
		catch(Exception e) {
			IDataUtil.put( pipelineCursor, "error", e.toString());
		}
		finally {
			pipelineCursor.destroy();
		}
		// --- <<IS-END>> ---

                
	}



	public static final void listFilesInDir (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(listFilesInDir)>> ---
		// @subtype unknown
		// @sigtype java 3.5

	//define input variables
	IDataCursor idcPipeline = pipeline.getCursor();
	String successFlag = "";
	String targetDirectory = null;

	// Check to see if the targetDirectory object is in the pipeline
	if (idcPipeline.first("targetDirectory"))
	{
			//get the targetDirectory out of the pipeline
			targetDirectory = (String)idcPipeline.getValue();
	}
	//if it is not in the pipeline, then handle the error
	else
	{
		//System.out.println("Error executing sample.io.utils:listFilesInDirectory: Required parameter 'targetDirectory' missing");
		successFlag = "No targetDirectory given";

   		//insert the successFlag into the pipeline
		idcPipeline.insertAfter("successFlag", successFlag);

		//Always destroy cursors that you created
		idcPipeline.destroy();
		return;
	}

	//String filenamePattern = null;

	// Check to see if the filenamePattern object is in the pipeline
	/*if (idcPipeline.first("filenamePattern"))
	{
			//get the filenamePattern out of the pipeline
			filenamePattern = (String)idcPipeline.getValue();
	}*/

	File targetDirectoryPath = new File (targetDirectory);

	if (!targetDirectoryPath.isDirectory () || !targetDirectoryPath.exists())
	{
		//System.out.println("Error executing sample.io.utils:listFilesInDirectory: Error reading directory!");
		successFlag = targetDirectoryPath + " is either not a directory or does not exist";

   		//insert the successFlag into the pipeline
		idcPipeline.insertAfter("successFlag", successFlag);

		//Always destroy cursors that you created
		idcPipeline.destroy();
		return;
	}

		idcPipeline.last ();
	String [] filenameList;


	//Check to see if filenamePattern is empty,
	//if ( (filenamePattern == null) || ((filenamePattern.trim ()).length () == 0) )
	//{

		//Load the direcotory listing
		filenameList = targetDirectoryPath.list ();
		
		//Check to see if directory empty
		if ( (filenameList == null) || (filenameList.length <= 0) )
		{
			filenameList=null;
			successFlag ="No files found in " + targetDirectoryPath;
		} else {
			successFlag ="OK";
		}
	//}
	/*else
	{
		//Load wild card filter which is located in: /packages/WmSamples/code/jars
		WCardDirFilter dirFilter = new WCardDirFilter (filenamePattern);

		//Search for matching filenames
		filenameList = targetDirectoryPath.list (dirFilter);
		successFlag ="true";

	}*/

		//insert the filenameList into the pipeline
		idcPipeline.insertAfter("filenameList", filenameList);


		//insert the successFlag into the pipeline
		idcPipeline.insertAfter("successFlag", successFlag);

		//Always destroy cursors that you created
		idcPipeline.destroy();
		// --- <<IS-END>> ---

                
	}



	public static final void mkDirs (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(mkDirs)>> ---
		// @subtype unknown
		// @sigtype java 3.5
		// [i] field:0:required dirs
		// [o] field:0:required status
		// [o] field:0:required error
		// Basic wrapper around Java File.mkdirs()
		
		// pipeline
		IDataCursor pipelineCursor = pipeline.getCursor();
		
		String dirs = IDataUtil.getString( pipelineCursor, "dirs" );
		
		try {
		  File f = new File(dirs);
		  boolean b=f.mkdirs();
		  IDataUtil.put( pipelineCursor, "status", b ? "success" : "fail");
		}
		catch(Exception e) {
			IDataUtil.put( pipelineCursor, "error", e.getMessage());
		}
		finally {
			pipelineCursor.destroy();
		}
		// --- <<IS-END>> ---

                
	}



	public static final void writeStringToFile (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(writeStringToFile)>> ---
		// @sigtype java 3.5
		// [i] field:0:required fileName
		// [i] field:0:required contents
		// [o] field:0:required status
		// [o] field:0:required error
		// [o] field:0:required absolutePath
		IDataCursor pipelineCursor = pipeline.getCursor();
		String status = "success";
		String fileName = IDataUtil.getString( pipelineCursor, "fileName" );
		String contents = IDataUtil.getString( pipelineCursor, "contents" );
		
		Writer fileWriter = null;
		try {
		    fileWriter = new BufferedWriter(new FileWriter(fileName, false));
		    fileWriter.write(contents);
		} catch (Exception e) {
			IDataUtil.put( pipelineCursor, "error", e.getMessage());
			status = "fail";
		} finally {
		    if (fileWriter != null) {
		        try {
					fileWriter.close();
				} catch (IOException e) {
					IDataUtil.put( pipelineCursor, "error", e.getMessage());
				}
		    }
		}
		IDataUtil.put( pipelineCursor, "status", status);
		IDataUtil.put( pipelineCursor, "absolutePath", new File(fileName).getAbsolutePath());
		pipelineCursor.destroy();
		// --- <<IS-END>> ---

                
	}
}

